# Chat Muffler

## Features
- bloat free
- mutes players
- mutes chat
- data saves past reboots
- more advanced mute time parser

## Time parser supports
year(y), month(m), week(w), day(d), hour(h), minute(i), second(s)
/mute bob 12h30i50s
will mute bob for 12 hours, 30 minutes, 50 seconds

muting with 0 will unmute,
and muting with -1 will mute forever 

## Coming soon
- mute ui for more advanced/easy operations
